<?php
/*
Plugin Name: Woo Schema Enhancer
Description: Adds shippingDetails and return policy to WooCommerce product schema with admin settings.
Version: 1.1.2
Author: Naimur Rahman Nahid
Author URI: https://www.lifemindbd.com
*/

add_action('admin_menu', 'wse_add_admin_menu');
function wse_add_admin_menu() {
    add_options_page('Woo Schema Enhancer Settings', 'Schema Enhancer', 'manage_options', 'woo-schema-enhancer', 'wse_settings_page');
}

add_action('admin_init', 'wse_register_settings');
function wse_register_settings() {
    register_setting('woo_schema_enhancer_settings', 'wse_return_days');
    register_setting('woo_schema_enhancer_settings', 'wse_shipping_country');
}

function wse_settings_page() {
?>
    <div class="wrap">
        <h1>Woo Schema Enhancer Settings</h1>
        <form method="post" action="options.php">
            <?php settings_fields('woo_schema_enhancer_settings'); ?>
            <?php do_settings_sections('woo_schema_enhancer_settings'); ?>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">Return Days</th>
                    <td><input type="number" name="wse_return_days" value="<?php echo esc_attr(get_option('wse_return_days', 7)); ?>" /></td>
                </tr>
                <tr valign="top">
                    <th scope="row">Shipping Country (ISO code)</th>
                    <td><input type="text" name="wse_shipping_country" value="<?php echo esc_attr(get_option('wse_shipping_country', 'BD')); ?>" /></td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
<?php
}

add_filter('woocommerce_structured_data_product', 'wse_modify_product_schema', 10, 2);
function wse_modify_product_schema($markup, $product) {
    $return_days = get_option('wse_return_days', 7);
    $shipping_country = get_option('wse_shipping_country', 'BD');

    $shippingDetails = array(
        '@type' => 'OfferShippingDetails',
        'shippingRate' => array(
            '@type' => 'MonetaryAmount',
            'value' => '0.00',
            'currency' => get_woocommerce_currency()
        ),
        'shippingDestination' => array(
            '@type' => 'DefinedRegion',
            'addressCountry' => $shipping_country
        ),
        'deliveryTime' => array(
            '@type' => 'ShippingDeliveryTime',
            'handlingTime' => array(
                '@type' => 'QuantitativeValue',
                'minValue' => 1,
                'maxValue' => 2,
                'unitCode' => 'd'
            ),
            'transitTime' => array(
                '@type' => 'QuantitativeValue',
                'minValue' => 2,
                'maxValue' => 4,
                'unitCode' => 'd'
            )
        )
    );

    $returnPolicy = array(
        '@type' => 'MerchantReturnPolicy',
        'applicableCountry' => $shipping_country,
        'returnPolicyCategory' => 'http://schema.org/MerchantReturnFiniteReturnWindow',
        'merchantReturnDays' => intval($return_days),
        'returnMethod' => 'http://schema.org/ReturnByMail',
        'returnFees' => 'http://schema.org/FreeReturn'
    );

    $markup['shippingDetails'] = $shippingDetails;
    $markup['hasMerchantReturnPolicy'] = $returnPolicy;

    if (isset($markup['offers'])) {
        if (is_array($markup['offers']) && isset($markup['offers'][0])) {
            foreach ($markup['offers'] as &$offer) {
                $offer['shippingDetails'] = $shippingDetails;
                $offer['hasMerchantReturnPolicy'] = $returnPolicy;
            }
        } elseif (is_array($markup['offers'])) {
            $markup['offers']['shippingDetails'] = $shippingDetails;
            $markup['offers']['hasMerchantReturnPolicy'] = $returnPolicy;
        }
    }

    return $markup;
}
