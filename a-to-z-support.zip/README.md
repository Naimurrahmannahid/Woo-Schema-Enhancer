# Woo Schema Enhancer

A lightweight WooCommerce plugin that extends the default product structured data by adding optional `shippingDetails` and `hasMerchantReturnPolicy` fields to improve Google Merchant Center compatibility.

## 🔧 Features

- Adds `shippingDetails` to product structured data
- Adds `hasMerchantReturnPolicy` to product structured data
- Easy admin settings panel to configure:
  - Return days
  - Shipping destination country (ISO code)
- Supports both single and multiple offers (array-based offers)

## 🚀 Why Use This?

Google Merchant Center often flags missing schema fields like `shippingDetails` and `hasMerchantReturnPolicy`. This plugin helps fix those warnings and boosts your product's eligibility for rich results.

## 🧩 Installation

1. Download the ZIP file or clone the repository.
2. Upload the plugin to your WordPress site:
   - WordPress Admin → Plugins → Add New → Upload Plugin
3. Activate the plugin.
4. Go to **Settings → Schema Enhancer** and configure your return days and shipping country.

## 🛠 Admin Panel Settings

- **Return Days**: Number of days allowed for product returns.
- **Shipping Country**: The ISO 3166-1 alpha-2 country code (e.g., `BD`, `US`, `GB`).

## 📦 Plugin Info

- **Version**: 1.1.2  
- **Author**: Naimur Rahman Nahid  
- **Website**: [https://www.lifemindbd.com](https://www.lifemindbd.com)

## ✅ Test Your Schema

Use [Google's Rich Results Test](https://search.google.com/test/rich-results) to validate your structured data after activation.

## 📃 License

This plugin is licensed under the [GPL v2 or later](https://www.gnu.org/licenses/gpl-2.0.html).
